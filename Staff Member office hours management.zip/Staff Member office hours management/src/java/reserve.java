/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author heba
 */
@WebServlet(urlPatterns = {"/reserve"})
public class reserve extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
     protected int sendEmail(String fromEmail,String toEmail, String pass, String msg, String subject) throws ParseException{
      int feedback;
         // Recipient's email ID needs to be mentioned.
      String to = toEmail;//change accordingly

      // Sender's email ID needs to be mentioned
      String from = fromEmail;//change accordingly
      final String username = fromEmail;//change accordingly
      final String password = pass;//change accordingly

      // Assuming you are sending email through relay.jangosmtp.net
      String host = "smtp.gmail.com";

      Properties props = new Properties();
      props.put("mail.smtp.auth", "true");
      props.put("mail.smtp.starttls.enable", "true");
      props.put("mail.smtp.host", host);
      props.put("mail.smtp.port", "587");
      props.put("mail.smtp.ssl.trust", "smtp.gmail.com");
     

      // Get the Session object.
      javax.mail.Session session = javax.mail.Session.getInstance(props,
      new javax.mail.Authenticator() {
         protected PasswordAuthentication getPasswordAuthentication() {
            return new PasswordAuthentication(username, password);
         }
      });

      try {
         // Create a default MimeMessage object.
         Message message = new MimeMessage(session);

         // Set From: header field of the header.
         message.setFrom(new InternetAddress(from));

         
         // Set To: header field of the header.
         message.setRecipients(Message.RecipientType.TO,
         InternetAddress.parse(to));

         // Set Subject: header field
         message.setSubject(subject);

         // Now set the actual message
         message.setText(msg);

         
         // Send message
         Transport.send(message);

         feedback = 1;

      } catch (MessagingException e) {
            //throw new RuntimeException(e);
            feedback = 0;
      }
         return feedback;
     }
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ParseException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
             Integer slotID = Integer.parseInt(request.getParameter("slot"));
             Integer sub = Integer.parseInt(request.getParameter("sub"));
             
            HttpSession session = request.getSession(false);
            Integer studentID =(int)session.getAttribute("id");
             String username = (String)session.getAttribute("username");
            
            //get staff id
            Session s = connection.Controller.getSessionFactory().openSession();
            Transaction tr = s.beginTransaction();
            String HQL = "from Slots where slotID = "+ slotID ;
            Query q = s.createQuery(HQL); 
            pojos.Slots slot = (pojos.Slots)q.uniqueResult();
            Integer staffID = slot.getSatffId();
            
            s.close();
            tr=null;
            
            //add to reservation
            Session s2 = connection.Controller.getSessionFactory().openSession();
            Transaction tr2 = s2.beginTransaction();
            pojos.Resevations reserve = new pojos.Resevations();
            reserve.setSlotId(slotID);
            reserve.setStaffId(staffID);
            reserve.setStudentId(studentID);
            reserve.setCanceled(0);
            s2.save(reserve);
            tr2.commit(); 
            s2.close();
            tr2=null;
            
            Session s3 = connection.Controller.getSessionFactory().openSession();
            Transaction tr3 = s3.beginTransaction();
            pojos.Slots slot2 = (pojos.Slots)s3.load(pojos.Slots.class, slotID);
            slot2.setReserved(1);
            tr3.commit(); 
            s3.close();
            tr3=null;
            
            Session s4 = connection.Controller.getSessionFactory().openSession();
            Transaction tr4 = s4.beginTransaction();
            pojos.Staff staff = (pojos.Staff)s4.load(pojos.Staff.class, staffID);
            
           
            
            String companyEmail ="meetingmanager151@gmail.com";
            String companyPassword ="87654321mm";
            String message = staff.getStaffUsername()+", one of your slots was reserved by "+username+".\n"+"on day: "+slot2.getDate()+"\n"+"from: "+slot2.getFromHr()+"\n"+"to: "+slot2.getToHr()+"\n we will remind you with an email on that day.";
            
            int verified = sendEmail(companyEmail,staff.getStaffEmail(),companyPassword,message, "A new Reservation");
            out.print(verified);
            s4.close();
            tr4 = null;
            
            String notification=staff.getStaffUsername()+", one of your slots was reserved by "+username+"on day:"+slot2.getDate()+"from:"+slot2.getFromHr()+"to:"+slot2.getToHr();
            Session s9 = connection.Controller.getSessionFactory().openSession();
            Transaction tr9 = s9.beginTransaction();
            pojos.Staffnotification noti = new pojos.Staffnotification();
            noti.setNotification(notification);
            noti.setStaffId(staffID);
            noti.setTitle("A New Reservation");
            s9.save(noti);
            tr9.commit();
            s9.close();
            tr9=null;
            
            response.sendRedirect("staffOfASubject.jsp?done=1&subject="+sub);
                
            
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         try {
             processRequest(request, response);
         } catch (ParseException ex) {
             Logger.getLogger(reserve.class.getName()).log(Level.SEVERE, null, ex);
         }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         try {
             processRequest(request, response);
         } catch (ParseException ex) {
             Logger.getLogger(reserve.class.getName()).log(Level.SEVERE, null, ex);
         }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
