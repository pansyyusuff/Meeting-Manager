/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.security.SecureRandom;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author heba
 */
@WebServlet(urlPatterns = {"/addStaff"})
public class addStaff extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected int sendEmail(String fromEmail,String toEmail, String pass, String msg, String subject){
      int feedback;
         // Recipient's email ID needs to be mentioned.
      String to = toEmail;//change accordingly

      // Sender's email ID needs to be mentioned
      String from = fromEmail;//change accordingly
      final String username = fromEmail;//change accordingly
      final String password = pass;//change accordingly

      // Assuming you are sending email through relay.jangosmtp.net
      String host = "smtp.gmail.com";

      Properties props = new Properties();
      props.put("mail.smtp.auth", "true");
      props.put("mail.smtp.starttls.enable", "true");
      props.put("mail.smtp.host", host);
      props.put("mail.smtp.port", "587");
      props.put("mail.smtp.ssl.trust", "smtp.gmail.com");
     

      // Get the Session object.
      javax.mail.Session session = javax.mail.Session.getInstance(props,
      new javax.mail.Authenticator() {
         protected PasswordAuthentication getPasswordAuthentication() {
            return new PasswordAuthentication(username, password);
         }
      });

      try {
         // Create a default MimeMessage object.
         Message message = new MimeMessage(session);

         // Set From: header field of the header.
         message.setFrom(new InternetAddress(from));

         // Set To: header field of the header.
         message.setRecipients(Message.RecipientType.TO,
         InternetAddress.parse(to));

         // Set Subject: header field
         message.setSubject(subject);

         // Now set the actual message
         message.setText(msg);

         // Send message
         Transport.send(message);

         feedback = 1;

      } catch (MessagingException e) {
            //throw new RuntimeException(e);
            feedback = 0;
      }
         return feedback;
     }
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            
            String email = request.getParameter("email");
            String username = request.getParameter("username");
            Integer mobile = Integer.parseInt(request.getParameter("mobile"));
            String name = request.getParameter("username");
            String prof = request.getParameter("prof");
            
            final String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            SecureRandom random = new SecureRandom();
            StringBuilder password = new StringBuilder();
            int len = 10;
            for (int i = 0; i < len; i++) {
                int randomIndex = random.nextInt(chars.length());
                password.append(chars.charAt(randomIndex));
            }
            String companyEmail ="meetingmanager151@gmail.com";
            String companyPassword ="87654321mm";
            String message = username+", Your account was verified successfuly, your password: "+password;
            
            int verified = sendEmail(companyEmail,email,companyPassword,message, "Account Verification");
            
            if(verified == 1){
            Session s = connection.Controller.getSessionFactory().openSession();
            Transaction tr = s.beginTransaction();
            pojos.Staff st = new pojos.Staff();
            st.setStaffName(name);
            st.setStaffUsername(username);
            st.setStaffMobile(mobile);
            st.setStaffEmail(email);
            st.setStaffPassword(String.valueOf(password));
            st.setStaffProf(prof);
            
            s.save(st);
            tr.commit();
            s.close();
            tr = null;

            //send verfication mail with the password
            
            Session s2 = connection.Controller.getSessionFactory().openSession();
            String HQL = "from Staff where staffUsername = '"+username+"'";
            Query q = s2.createQuery(HQL);
            pojos.Staff st2 = (pojos.Staff)q.uniqueResult();
            
            Integer id = st2.getStaffId();
            HttpSession session = request.getSession();
            session.setAttribute("id", id);
            session.setAttribute("name", name);
            session.setAttribute("username", username);
            session.setAttribute("email", email);
            session.setAttribute("mobile", mobile);
            session.setAttribute("prof", prof);
            response.sendRedirect("staff profile.jsp?addslot=0&addsubject=0&update=0&updateslot=0&deletesubject=0&deleteslot=0"); 
            }else{
               response.sendRedirect("staff signup.jsp?verify=0"); 
            }
            
            }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
