/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.util.List;
import java.util.Properties;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author heba
 */
@WebServlet(urlPatterns = {"/deleteMultiReservation"})
public class deleteMultiReservation extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
     protected int sendEmail(String fromEmail,String toEmail, String pass, String msg, String subject) throws ParseException{
      int feedback;
         // Recipient's email ID needs to be mentioned.
      String to = toEmail;//change accordingly

      // Sender's email ID needs to be mentioned
      String from = fromEmail;//change accordingly
      final String username = fromEmail;//change accordingly
      final String password = pass;//change accordingly

      // Assuming you are sending email through relay.jangosmtp.net
      String host = "smtp.gmail.com";

      Properties props = new Properties();
      props.put("mail.smtp.auth", "true");
      props.put("mail.smtp.starttls.enable", "true");
      props.put("mail.smtp.host", host);
      props.put("mail.smtp.port", "587");
      props.put("mail.smtp.ssl.trust", "smtp.gmail.com");
     

      // Get the Session object.
      javax.mail.Session session = javax.mail.Session.getInstance(props,
      new javax.mail.Authenticator() {
         protected PasswordAuthentication getPasswordAuthentication() {
            return new PasswordAuthentication(username, password);
         }
      });

      try {
         // Create a default MimeMessage object.
         Message message = new MimeMessage(session);

         // Set From: header field of the header.
         message.setFrom(new InternetAddress(from));

         
         // Set To: header field of the header.
         message.setRecipients(Message.RecipientType.TO,
         InternetAddress.parse(to));

         // Set Subject: header field
         message.setSubject(subject);

         // Now set the actual message
         message.setText(msg);

         
         // Send message
         Transport.send(message);

         feedback = 1;

      } catch (MessagingException e) {
            //throw new RuntimeException(e);
            feedback = 0;
      }
         return feedback;
     }
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ParseException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String date = request.getParameter("day");
            
            HttpSession session = request.getSession(false);
            int staffID =(int)session.getAttribute("id");
            String username = (String)session.getAttribute("username");
            
           
            
            Vector<Integer> slotsID = new Vector();
            Vector<Integer> studentsID = new Vector();
            Vector<Integer> reservationID = new Vector();
            
            Session s = connection.Controller.getSessionFactory().openSession();
            Transaction tr = s.beginTransaction();
            String HQL="from Slots where satffID = "+staffID+" and Date = '"+date+"' and reserved = 1";
            Query q = s.createQuery(HQL);
            List<pojos.Slots> list = q.list();
            
            if(list.isEmpty()){
                out.print("here");
                response.sendRedirect("appointments.jsp?delete=2");
            }else{
                for(pojos.Slots slot:list){
                    slotsID.add(slot.getSlotId());
                }   
            s.close();
            tr = null;
            
            for(int i=0;i<slotsID.size();i++){
                s = connection.Controller.getSessionFactory().openSession();
                tr = s.beginTransaction();
                pojos.Slots slot = (pojos.Slots)s.load(pojos.Slots.class, slotsID.get(i));
                slot.setReserved(0);
                s.save(slot);
                tr.commit();
                s.close();
                tr=null;
            }
           
            for(int i=0;i<slotsID.size();i++){
               Session s3 = connection.Controller.getSessionFactory().openSession();
               Transaction tr3 = s3.beginTransaction(); 
               String HQL3="from Resevations where slotID = "+slotsID.get(i);
               Query q3 = s3.createQuery(HQL3);
               List<pojos.Resevations> list3 = q3.list();
               for(pojos.Resevations r:list3){
                   if(r.getCanceled()==0){
                         studentsID.add(r.getStudentId());
                         reservationID.add(r.getResevationId());
                    }
                }
                s3.close();
                tr3=null;
            }
            for(int i =0;i<reservationID.size();i++){
                s = connection.Controller.getSessionFactory().openSession();
                tr = s.beginTransaction();
                pojos.Resevations r = (pojos.Resevations)s.load(pojos.Resevations.class, reservationID.get(i));
                r.setCanceled(1);
                s.save(r);
                tr.commit();
                s.close();
                tr=null; 
            }
            
            String companyEmail ="meetingmanager151@gmail.com";
            String companyPassword ="87654321mm";
            
            
           
            int verified =0;
            for(int i=0;i<studentsID.size();i++){
                Session s2 = connection.Controller.getSessionFactory().openSession();
                Transaction tr2 = s2.beginTransaction();
                pojos.Students student = (pojos.Students)s2.load(pojos.Students.class, studentsID);
                String message = student.getStudentUsername()+", one of your appointments was canceled by "+username+".\n"+"on day: "+date+".";
                verified = sendEmail(companyEmail,student.getStudentEmail(),companyPassword,message, "A Reservation Was Canceled");
                s2.close();
                tr2 = null;

            }
           
            response.sendRedirect("appointments.jsp?delete=1");
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         try {
             processRequest(request, response);
         } catch (ParseException ex) {
             Logger.getLogger(deleteMultiReservation.class.getName()).log(Level.SEVERE, null, ex);
         }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         try {
             processRequest(request, response);
         } catch (ParseException ex) {
             Logger.getLogger(deleteMultiReservation.class.getName()).log(Level.SEVERE, null, ex);
         }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
