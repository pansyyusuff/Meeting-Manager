/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.util.List;
import java.util.Properties;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author heba
 */
@WebServlet(urlPatterns = {"/sendEmailToManyStaff"})
public class sendEmailToManyStaff extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
      protected int sendEmail(String fromEmail,String toEmail, String pass, String msg, String subject) throws ParseException{
      int feedback;
         // Recipient's email ID needs to be mentioned.
      String to = toEmail;//change accordingly

      // Sender's email ID needs to be mentioned
      String from = fromEmail;//change accordingly
      final String username = fromEmail;//change accordingly
      final String password = pass;//change accordingly

      // Assuming you are sending email through relay.jangosmtp.net
      String host = "smtp.gmail.com";

      Properties props = new Properties();
      props.put("mail.smtp.auth", "true");
      props.put("mail.smtp.starttls.enable", "true");
      props.put("mail.smtp.host", host);
      props.put("mail.smtp.port", "587");
      props.put("mail.smtp.ssl.trust", "smtp.gmail.com");
     

      // Get the Session object.
      javax.mail.Session session = javax.mail.Session.getInstance(props,
      new javax.mail.Authenticator() {
         protected PasswordAuthentication getPasswordAuthentication() {
            return new PasswordAuthentication(username, password);
         }
      });

      try {
         // Create a default MimeMessage object.
         Message message = new MimeMessage(session);

         // Set From: header field of the header.
         message.setFrom(new InternetAddress(from));

         
         // Set To: header field of the header.
         message.setRecipients(Message.RecipientType.TO,
         InternetAddress.parse(to));

         // Set Subject: header field
         message.setSubject(subject);

         // Now set the actual message
         message.setText(msg);

         
         // Send message
         Transport.send(message);

         feedback = 1;

      } catch (MessagingException e) {
            //throw new RuntimeException(e);
            feedback = 2;
      }
         return feedback;
     }
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ParseException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
             int sub = Integer.parseInt(request.getParameter("sub"));
            int to = Integer.parseInt(request.getParameter("to"));
            String pass = request.getParameter("password");
            String msg = request.getParameter("message");
            String subject = request.getParameter("subject");
            String dir = request.getParameter("dir");
            
            Vector<String> emails= new Vector();
            Vector<Integer> Ids= new Vector();

            HttpSession session = request.getSession(false);
            String name =(String)session.getAttribute("name");
            String username =(String)session.getAttribute("username");
            String fromEmail =(String)session.getAttribute("email");
            int ID =(int)session.getAttribute("id");
          

            Session s0 = connection.Controller.getSessionFactory().openSession();
            Transaction tr0 = s0.beginTransaction();
            String HQL0 ="from Teaches where subjectID = "+sub;
            Query q0 = s0.createQuery(HQL0);
            List<pojos.Teaches> telist = q0.list();
            for(pojos.Teaches te:telist){ 
                    Session s = connection.Controller.getSessionFactory().openSession();
                    Transaction tr = s.beginTransaction();
                    String HQL = "from Staff where staffID = "+ te.getStaffId() ;
                    Query q = s.createQuery(HQL); 
                    pojos.Staff st = (pojos.Staff)q.uniqueResult();
                    if(st.getStaffEmail().equals(fromEmail)){
                   
                        continue;
                    }else{
                        if(to==1 && st.getStaffProf().equals("Dr")){
                            emails.add(st.getStaffEmail());
                            Ids.add(st.getStaffId());
                        }
                        if(to==2 && st.getStaffProf().equals("TA")){
                            emails.add(st.getStaffEmail());
                            Ids.add(st.getStaffId());
                        }
                        if(to==3){
                            emails.add(st.getStaffEmail());
                            Ids.add(st.getStaffId());
                        }
                    }
            }
            s0.close();
            tr0=null;
            int done = 5;
            for(int i=0;i<emails.size();i++){
                out.print(emails.get(i));
                done = sendEmail(fromEmail,emails.get(i), pass, msg, subject);
            }
            out.print(done);
            if(done==1){
                for(int i=0;i<Ids.size();i++){
                    Session s = connection.Controller.getSessionFactory().openSession();
                    Transaction tr = s.beginTransaction();
                    pojos.Staffmessages message = new pojos.Staffmessages();
                    message.setMessage(msg);
                    message.setSent(0);
                    message.setStaffId(Ids.get(i));
                    message.setStudentId(ID);
                    message.setSubject(subject);
                    
                    s.save(message);
                    tr.commit();
                    s.close();
                    tr=null;
                }
            }
            response.sendRedirect("contactMulti.jsp?sub="+sub+"&to="+to+"&feedback="+done);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
          try {
              processRequest(request, response);
          } catch (ParseException ex) {
              Logger.getLogger(sendEmailToManyStaff.class.getName()).log(Level.SEVERE, null, ex);
          }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
          try {
              processRequest(request, response);
          } catch (ParseException ex) {
              Logger.getLogger(sendEmailToManyStaff.class.getName()).log(Level.SEVERE, null, ex);
          }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
